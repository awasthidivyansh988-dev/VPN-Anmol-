package com.anmol.vpn.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class VpnConfig(
    val serverId: String,
    val serverName: String,
    val serverCountry: String,
    val endpoint: String,
    val serverPublicKey: String,
    val clientPrivateKey: String,
    val tunnelIpv4Address: String = "10.8.0.2",
    val tunnelIpv6Address: String = "fd42:42:42::2",
    val dnsServers: List<String> = listOf("1.1.1.1", "1.0.0.1"),
    val allowedIps: List<String> = listOf("0.0.0.0/0", "::/0"),
    val mtu: Int = 1420,
    val presharedKey: String? = null,
    val persistentKeepalive: Int = 25,
    val killSwitchEnabled: Boolean = true,
    val dnsLeakProtectionEnabled: Boolean = true
) : Parcelable {

    fun toWireGuardQuickFormat(): String {
        val sb = StringBuilder()
        sb.append("[Interface]\n")
        sb.append("PrivateKey = ").append(clientPrivateKey).append("\n")
        sb.append("Address = ").append(tunnelIpv4Address).append("/24, ").append(tunnelIpv6Address).append("/64\n")
        sb.append("DNS = ").append(dnsServers.joinToString(", ")).append("\n")
        sb.append("MTU = ").append(mtu).append("\n\n")

        sb.append("[Peer]\n")
        sb.append("PublicKey = ").append(serverPublicKey).append("\n")
        if (!presharedKey.isNullOrBlank()) {
            sb.append("PresharedKey = ").append(presharedKey).append("\n")
        }
        sb.append("Endpoint = ").append(endpoint).append("\n")
        sb.append("AllowedIPs = ").append(allowedIps.joinToString(", ")).append("\n")
        sb.append("PersistentKeepalive = ").append(persistentKeepalive).append("\n")
        return sb.toString()
    }
}