package com.anmol.vpn.model

data class VpnServer(
    val id: String,
    val name: String,
    val country: String,
    val countryCode: String,
    val city: String,
    val flag: String,
    val endpoint: String,
    val publicKey: String,
    val pingMs: Int,
    val loadPercent: Int,
    val isDefault: Boolean = false
)

object ServerCatalog {
    val servers = listOf(
        VpnServer("sg-main", "Singapore - Primary", "Singapore", "SG", "Jurong West", "🇸🇬", "sg1.vpn.anmolvpn.net:51820", "aNmOLvPnSg1kEy99x2Z7Lq8vPtR+Wj12N45BvM8Xq0=", 22, 38, true),
        VpnServer("in-mumbai", "India - Mumbai", "India", "IN", "Mumbai", "🇮🇳", "in1.vpn.anmolvpn.net:51820", "aNmOLvPnIn1kEy34b7Z1Wp9vLtM+Kj78P32BvM1Zq9=", 16, 64),
        VpnServer("us-east", "United States - New York", "United States", "US", "New York", "🇺🇸", "us1.vpn.anmolvpn.net:51820", "aNmOLvPnUs1kEy12w8X4Kl7vRtQ+Nj56V90BvM4Yq2=", 138, 52),
        VpnServer("uk-london", "United Kingdom - London", "United Kingdom", "GB", "London", "🇬🇧", "uk1.vpn.anmolvpn.net:51820", "aNmOLvPnUk1kEy89m3V2Np5vBtR+Hj23C45BvM7Tq6=", 116, 44),
        VpnServer("de-frankfurt", "Germany - Frankfurt", "Germany", "DE", "Frankfurt", "🇩🇪", "de1.vpn.anmolvpn.net:51820", "aNmOLvPnDe1kEy67t4F8Rq2vMtP+Wj67L89BvM3Kq1=", 112, 35),
        VpnServer("jp-tokyo", "Japan - Tokyo", "Japan", "JP", "Tokyo", "🇯🇵", "jp1.vpn.anmolvpn.net:51820", "aNmOLvPnJp1kEy55y9H2Gk6vStN+Qj89R12BvM9Lq4=", 58, 49),
        VpnServer("nl-amsterdam", "Netherlands - Amsterdam", "Netherlands", "NL", "Amsterdam", "🇳🇱", "nl1.vpn.anmolvpn.net:51820", "aNmOLvPnNl1kEy77v2R8Tk4vYtP+Wj99D12BvM6Pq8=", 108, 41),
        VpnServer("ca-toronto", "Canada - Toronto", "Canada", "CA", "Toronto", "🇨🇦", "ca1.vpn.anmolvpn.net:51820", "aNmOLvPnCa1kEy44z9P1Lk3vRtM+Kj88Q34BvM2Tq5=", 145, 32)
    )
}