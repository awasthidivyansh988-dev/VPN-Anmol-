package com.anmol.vpn.ui

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.anmol.vpn.model.VpnConfig
import com.anmol.vpn.service.AnmolVpnService
import com.anmol.vpn.ui.screens.MainVpnApp
import com.anmol.vpn.ui.theme.AnmolVpnTheme

class MainActivity : ComponentActivity() {

    private var pendingVpnConfig: VpnConfig? = null

    private val vpnConsentLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            pendingVpnConfig?.let { startVpnServiceDirectly(it) }
        } else {
            Toast.makeText(this, "VPN permission was not granted.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            AnmolVpnTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainVpnApp(
                        onConnectRequested = { config -> handleConnectRequest(config) },
                        onDisconnectRequested = { disconnectVpn() }
                    )
                }
            }
        }
    }

    private fun handleConnectRequest(config: VpnConfig) {
        pendingVpnConfig = config
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            vpnConsentLauncher.launch(prepareIntent)
        } else {
            startVpnServiceDirectly(config)
        }
    }

    private fun startVpnServiceDirectly(config: VpnConfig) {
        val serviceIntent = Intent(this, AnmolVpnService::class.java).apply {
            action = AnmolVpnService.ACTION_CONNECT
            putExtra(AnmolVpnService.EXTRA_CONFIG, config)
        }
        startService(serviceIntent)
    }

    private fun disconnectVpn() {
        val serviceIntent = Intent(this, AnmolVpnService::class.java).apply {
            action = AnmolVpnService.ACTION_DISCONNECT
        }
        startService(serviceIntent)
    }
}