package com.anmol.vpn.service

import com.wireguard.android.backend.Tunnel

class AnmolTunnel(private val name: String) : Tunnel {
    override fun getName(): String = name
    override fun onStateChange(newState: Tunnel.State) {
        // State updates synchronized via VpnRepository
    }
}