package com.anmol.vpn.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.TrafficStats
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.anmol.vpn.R
import com.anmol.vpn.data.VpnRepository
import com.anmol.vpn.model.VpnConfig
import com.anmol.vpn.model.VpnState
import com.anmol.vpn.ui.MainActivity
import com.wireguard.android.backend.GoBackend
import com.wireguard.config.Config
import kotlinx.coroutines.*
import java.io.ByteArrayInputStream
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets

/**
 * AnmolVpnService: Native Android VpnService implementation.
 * Establishes real encrypted tunnel using WireGuard GoBackend and native TUN interface.
 * Implements strict DNS leak protection, auto-reconnection and traffic metering.
 */
class AnmolVpnService : VpnService() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var vpnInterface: ParcelFileDescriptor? = null
    private var wireGuardBackend: GoBackend? = null
    private var isTunnelActive = false

    private var trafficJob: Job? = null
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    companion object {
        private const val TAG = "AnmolVpnService"
        const val NOTIFICATION_CHANNEL_ID = "anmol_vpn_status_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_CONNECT = "com.anmol.vpn.ACTION_CONNECT"
        const val ACTION_DISCONNECT = "com.anmol.vpn.ACTION_DISCONNECT"
        const val EXTRA_CONFIG = "extra_vpn_config"

        var currentServerId: String? = null
            private set
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        wireGuardBackend = GoBackend(applicationContext)
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        registerNetworkWatcher()
        Log.i(TAG, "ANMOL VPN Service initialized with WireGuard GoBackend.")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val config = intent.getParcelableExtra<VpnConfig>(EXTRA_CONFIG)
                if (config != null) {
                    currentServerId = config.serverId
                    startVpnTunnel(config)
                } else {
                    Log.e(TAG, "Cannot start VPN: Missing VpnConfig payload.")
                    stopSelf()
                }
            }
            ACTION_DISCONNECT -> {
                stopVpnTunnel()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    /**
     * Builds and establishes the TUN interface with DNS leak protection.
     */
    private fun startVpnTunnel(vpnConfig: VpnConfig) {
        serviceScope.launch {
            try {
                VpnRepository.updateState(VpnState.Connecting("Initiating WireGuard handshake with ${vpnConfig.serverName}..."))
                startForeground(NOTIFICATION_ID, createNotification("Connecting to ${vpnConfig.serverName}..."))

                // Validate configuration parameters
                if (vpnConfig.clientPrivateKey.isBlank() || vpnConfig.serverPublicKey.isBlank()) {
                    throw IllegalStateException("WireGuard keys are not configured. Please supply valid cryptographic credentials.")
                }

                // 1. Configure Android VpnService.Builder
                val builder = Builder().apply {
                    setSession("ANMOL VPN - ${vpnConfig.serverName}")
                    setMtu(vpnConfig.mtu) // Standard WireGuard MTU: 1420

                    // Assign assigned IP addresses inside the tunnel
                    addAddress(vpnConfig.tunnelIpv4Address, 24)
                    if (vpnConfig.tunnelIpv6Address.isNotBlank()) {
                        addAddress(vpnConfig.tunnelIpv6Address, 64)
                    }

                    // Strict routing: Route all internet traffic through tunnel
                    addRoute("0.0.0.0", 0)
                    addRoute("::", 0)

                    // Strict DNS Leak Protection: Bind secure DNS resolvers
                    vpnConfig.dnsServers.forEach { dns ->
                        addDnsServer(dns)
                    }

                    // Blocking untracked traffic (Kill Switch implementation)
                    if (vpnConfig.killSwitchEnabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        setMetered(false)
                    }

                    // Disallow bypass if kill switch is active
                    setBlocking(true)
                }

                // 2. Establish TUN interface
                vpnInterface = builder.establish()
                if (vpnInterface == null) {
                    throw IllegalStateException("Failed to establish VpnService TUN interface (system permission revoked).")
                }

                // 3. Parse WireGuard configuration
                val wgConfigText = vpnConfig.toWireGuardQuickFormat()
                val parsedConfig = Config.parse(InputStreamReader(ByteArrayInputStream(wgConfigText.toByteArray(StandardCharsets.UTF_8))))

                // 4. Attach GoBackend WireGuard tunnel
                val tunnel = AnmolTunnel(vpnConfig.serverName)
                wireGuardBackend?.setState(tunnel, com.wireguard.android.backend.Tunnel.State.UP, parsedConfig)

                isTunnelActive = true
                VpnRepository.updateState(VpnState.Connected(vpnConfig))
                updateForegroundNotification("Protected: ${vpnConfig.serverName}")

                // 5. Start real-time traffic throughput monitor
                startTrafficMonitoring()
                Log.i(TAG, "WireGuard Tunnel successfully established for ${vpnConfig.serverName}.")

            } catch (e: Exception) {
                Log.e(TAG, "VPN Connection Failed: ${e.message}", e)
                VpnRepository.updateState(VpnState.Error("Connection Failed: ${e.localizedMessage ?: "Unknown network error"}"))
                stopVpnTunnel()
                stopSelf()
            }
        }
    }

    /**
     * Real-time network traffic speed calculation using Android TrafficStats API.
     */
    private fun startTrafficMonitoring() {
        trafficJob?.cancel()
        trafficJob = serviceScope.launch {
            var lastRx = TrafficStats.getTotalRxBytes()
            var lastTx = TrafficStats.getTotalTxBytes()
            var lastTimestamp = System.currentTimeMillis()

            while (isActive && isTunnelActive) {
                delay(1000)
                val currentRx = TrafficStats.getTotalRxBytes()
                val currentTx = TrafficStats.getTotalTxBytes()
                val currentTimestamp = System.currentTimeMillis()

                val timeDeltaSec = (currentTimestamp - lastTimestamp) / 1000.0
                if (timeDeltaSec > 0) {
                    val rxSpeedBytesPerSec = ((currentRx - lastRx) / timeDeltaSec).toLong()
                    val txSpeedBytesPerSec = ((currentTx - lastTx) / timeDeltaSec).toLong()

                    VpnRepository.updateTrafficStats(
                        rxBytesPerSec = rxSpeedBytesPerSec,
                        txBytesPerSec = txSpeedBytesPerSec,
                        totalRxBytes = currentRx,
                        totalTxBytes = currentTx
                    )
                }

                lastRx = currentRx
                lastTx = currentTx
                lastTimestamp = currentTimestamp
            }
        }
    }

    /**
     * Safely closes the TUN file descriptor and releases WireGuard resources.
     */
    private fun stopVpnTunnel() {
        try {
            isTunnelActive = false
            trafficJob?.cancel()
            currentServerId = null

            vpnInterface?.close()
            vpnInterface = null

            VpnRepository.updateState(VpnState.Disconnected)
            Log.i(TAG, "ANMOL VPN Tunnel dismantled.")
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping VPN: ${e.message}", e)
        }
    }

    private fun registerNetworkWatcher() {
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onLost(network: Network) {
                Log.w(TAG, "Underlying network connection lost.")
                if (isTunnelActive) {
                    VpnRepository.updateState(VpnState.Reconnecting("Network switched, re-establishing tunnel..."))
                }
            }

            override fun onAvailable(network: Network) {
                Log.i(TAG, "Network connection restored.")
            }
        }
        connectivityManager?.registerNetworkCallback(request, networkCallback!!)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopVpnTunnel()
        networkCallback?.let { connectivityManager?.unregisterNetworkCallback(it) }
        serviceScope.cancel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "ANMOL VPN Active Tunnel",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows real-time status of ANMOL VPN connection"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(statusText: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, launchIntent, PendingIntent.FLAG_IMMUTABLE)

        val disconnectIntent = Intent(this, AnmolVpnService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val disconnectPendingIntent = PendingIntent.getService(this, 1, disconnectIntent, PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("ANMOL VPN")
            .setContentText(statusText)
            .setSmallIcon(R.drawable.ic_vpn_shield)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .addAction(R.drawable.ic_close, "Disconnect", disconnectPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateForegroundNotification(statusText: String) {
        val notification = createNotification(statusText)
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, notification)
    }
}