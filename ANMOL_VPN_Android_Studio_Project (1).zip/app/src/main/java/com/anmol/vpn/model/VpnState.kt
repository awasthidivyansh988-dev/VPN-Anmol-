package com.anmol.vpn.model

sealed class VpnState {
    object Disconnected : VpnState()
    data class Connecting(val step: String = "Connecting...") : VpnState()
    data class Connected(val config: VpnConfig) : VpnState()
    data class Reconnecting(val reason: String) : VpnState()
    data class Error(val errorMessage: String) : VpnState()
}

data class TrafficData(
    val rxBytesPerSec: Long = 0,
    val txBytesPerSec: Long = 0,
    val totalRxBytes: Long = 0,
    val totalTxBytes: Long = 0,
    val durationSeconds: Long = 0
)

data class SessionHistory(
    val id: String,
    val serverName: String,
    val country: String,
    val flag: String,
    val timestamp: String,
    val durationSeconds: Long,
    val bytesUsed: Long
)