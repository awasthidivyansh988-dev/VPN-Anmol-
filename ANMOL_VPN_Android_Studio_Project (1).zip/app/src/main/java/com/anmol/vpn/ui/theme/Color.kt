package com.anmol.vpn.ui.theme

import androidx.compose.ui.graphics.Color

val DarkNavyBg = Color(0xFF070B19)
val CardNavy = Color(0xFF0B132B)
val BorderNavy = Color(0xFF1C2541)
val ElectricCyan = Color(0xFF00F0FF)
val NeonPurple = Color(0xFFA855F7)
val CyberBlue = Color(0xFF38BDF8)
val AccentBlue = Color(0xFF3A86FF)
val SuccessEmerald = Color(0xFF10B981)
val ErrorRose = Color(0xFFEF4444)
val WarningAmber = Color(0xFFF59E0B)