package com.anmol.vpn.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import com.anmol.vpn.model.TrafficData
import com.anmol.vpn.model.VpnConfig
import com.anmol.vpn.model.VpnState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object VpnRepository {

    private val _vpnState = MutableStateFlow<VpnState>(VpnState.Disconnected)
    val vpnState: StateFlow<VpnState> = _vpnState.asStateFlow()

    private val _trafficStats = MutableStateFlow(TrafficData())
    val trafficStats: StateFlow<TrafficData> = _trafficStats.asStateFlow()

    fun updateState(state: VpnState) {
        _vpnState.value = state
    }

    fun updateTrafficStats(rxBytesPerSec: Long, txBytesPerSec: Long, totalRxBytes: Long, totalTxBytes: Long) {
        val current = _trafficStats.value
        _trafficStats.value = current.copy(
            rxBytesPerSec = rxBytesPerSec,
            txBytesPerSec = txBytesPerSec,
            totalRxBytes = totalRxBytes,
            totalTxBytes = totalTxBytes,
            durationSeconds = current.durationSeconds + 1
        )
    }

    /**
     * Stores client keys in Android Keystore backed EncryptedSharedPreferences.
     */
    fun getSecurePreferences(context: Context) = EncryptedSharedPreferences.create(
        "anmol_vpn_vault",
        MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),
        context,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
}