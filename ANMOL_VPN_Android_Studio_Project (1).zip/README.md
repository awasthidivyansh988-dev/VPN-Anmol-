# ANMOL VPN - Native Android WireGuard Application

ANMOL VPN is a modern, enterprise-grade Android VPN client built with **Kotlin**, **Android VpnService**, and the **WireGuard** GoBackend protocol.

---

## 🚀 Key Features

- **8 Global Locations**: Singapore (Primary), India, United States, United Kingdom, Germany, Japan, Netherlands, Canada.
- **Android VpnService Integration**: Uses official `VpnService.Builder` to route IPv4 and IPv6 traffic.
- **WireGuard Protocol**: ChaCha20-Poly1305 encryption, Curve25519 key exchange, 1-RTT handshake.
- **Zero-Logs Architecture**: No packet inspection, no connection timestamp logs, RAM-only execution.
- **DNS Leak Protection**: Forces encrypted DNS resolvers (`1.1.1.1` / `1.0.0.1`) preventing ISP snooping.
- **Live TrafficStats**: Real-time download/upload speed gauges using Linux socket counters.
- **Kill Switch**: Blocks unencrypted leaks if the tunnel drops.
- **Splash Screen & Material 3**: Electric blue and purple gradients with glassmorphic cards.

---

## 🛠️ Building the APK

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34 (Upside Down Cake)
- JDK 17
- NDK (for WireGuard native GoBackend: `arm64-v8a`, `armeabi-v7a`, `x86_64`)

### 1. Build Debug APK
```bash
./gradlew assembleDebug
```
The generated APK will be at:
`app/build/outputs/apk/debug/app-debug.apk`

### 2. Build Signed Release APK
```bash
./gradlew assembleRelease
```

---

## 🌐 Deploying Your Singapore WireGuard Server

```bash
docker run -d \
  --name=wg-easy \
  -e WG_HOST=YOUR_SINGAPORE_VPS_IP \
  -e PASSWORD=admin_secret_pass \
  -v ~/.wg-easy:/etc/wireguard \
  -p 51820:51820/udp \
  -p 51821:51821/tcp \
  --cap-add=NET_ADMIN \
  --cap-add=SYS_MODULE \
  --sysctl="net.ipv4.conf.all.src_valid_mark=1" \
  --sysctl="net.ipv4.ip_forward=1" \
  ghcr.io/wg-easy/wg-easy
```
